document.addEventListener('DOMContentLoaded', function () {
    // Ambil data booking dari localStorage
    const bookings = JSON.parse(localStorage.getItem('bookings')) || { 1: [], 2: [] };
    const bookingTable = document.querySelector('.booking-table');
    const now = new Date();

    if (bookingTable) {
        let tableContent = `
            <tr>
                <th>Lapangan</th>
                <th>Tanggal</th>
                <th>Jam Mulai</th>
                <th>Jam Selesai</th>
            </tr>
        `;
        let hasBooking = false;

        Object.keys(bookings).forEach(lapangan => {
            bookings[lapangan].forEach(booking => {
                const bookingDateTime = new Date(`${booking.tanggal} ${booking.jamSelesai}`);
                if (bookingDateTime > now) { // Hanya tampilkan booking yang masih berlaku
                    const [year, month, day] = booking.tanggal.split('-');
                    const formattedDate = `${day}-${month}-${year}`;
                    tableContent += `
                        <tr>
                            <td>Lapangan ${lapangan}</td>
                            <td>${formattedDate}</td>
                            <td>${booking.jamMulai}</td>
                            <td>${booking.jamSelesai}</td>
                        </tr>
                    `;
                    hasBooking = true;
                }
            });
        });

        if (!hasBooking) {
            tableContent += `
                <tr>
                    <td colspan="4" style="text-align: center;">Tidak ada jadwal yang dipesan.</td>
                </tr>
            `;
        }

        bookingTable.innerHTML = tableContent;
    }
});

// sub menu
let subMenu = document.getElementById("subMenu");

function toggleMenu() {
    subMenu.classList.toggle("open-menu");
}


document.addEventListener('DOMContentLoaded', function () {
    const sidebar = document.getElementById('sidebar');
    const overlay = document.getElementById('overlay');
    const closeButton = document.getElementById('close-button');
    const menuButton = document.getElementById('menu-button'); // Jika ada tombol untuk membuka sidebar

    function showSidebar() {
        if (sidebar && overlay) {
            sidebar.classList.add('open');
            overlay.classList.add('show');
        }
    }

    function closeSidebar() {
        if (sidebar && overlay) {
            sidebar.classList.remove('open');
            overlay.classList.remove('show');
        }
    }

    if (menuButton) {
        menuButton.addEventListener('click', showSidebar);
    }
    if (closeButton) {
        closeButton.addEventListener('click', closeSidebar);
    }
    if (overlay) {
        overlay.addEventListener('click', closeSidebar);
    }

    // Sub Menu
    let subMenu = document.getElementById("subMenu");
    function toggleMenu() {
        if (subMenu) {
            subMenu.classList.toggle("open-menu");
        }
    }

   
    });
