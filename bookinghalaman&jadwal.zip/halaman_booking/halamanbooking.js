function bookingLapangan() {
    return {
        hargaSiang: 35000,
        hargaMalam: 40000,
        hargaLapangan: 35000,
        bookings: JSON.parse(localStorage.getItem('bookings')) || { 1: [], 2: [] },
        nomorTelepon: '',
        nama: '',
        lapanganDipilih: '',
        tanggalBooking: '',
        jamMulai: '',
        durasi: '1',
        jamSelesai: '',

        hitungJamSelesai() {
            if (this.jamMulai) {
                let [jam, menit] = this.jamMulai.split(':').map(Number);
                jam += parseInt(this.durasi);
                if (jam >= 24) jam -= 24;
                this.jamSelesai = `${String(jam).padStart(2, '0')}:${String(menit).padStart(2, '0')}`;

                let jamBooking = parseInt(this.jamMulai.split(':')[0]);
                this.hargaLapangan = (jamBooking >= 6 && jamBooking < 18) ? this.hargaSiang : this.hargaMalam;
            }
        },

        isSlotAvailable(jamMulai, jamSelesai, tanggal, lapangan) {
            return !this.bookings[lapangan].some(booking => {
                return booking.tanggal === tanggal && (jamMulai < booking.jamSelesai && jamSelesai > booking.jamMulai);
            });
        },

        isValidPhoneNumber(number) {
            const phoneRegex = /^[0-9]{10,15}$/;
            return phoneRegex.test(number);
        },

        isValidBooking() {
            const today = new Date();
            const todayMidnight = new Date();
            todayMidnight.setHours(0, 0, 0, 0);
            const bookingDate = new Date(this.tanggalBooking);
            
            if (bookingDate < todayMidnight) {
                alert("Tidak bisa melakukan booking untuk tanggal yang sudah lewat!");
                return false;
            }
            
            const [jam, menit] = this.jamMulai.split(':').map(Number);
            const bookingDateTime = new Date(this.tanggalBooking);
            bookingDateTime.setHours(jam, menit);

            if (bookingDateTime.getTime() <= today.getTime()) {
                alert("Tidak bisa melakukan booking untuk waktu yang sudah lewat!");
                return false;
            }
            
            if (!this.isValidPhoneNumber(this.nomorTelepon)) {
                alert("Masukkan nomor telepon yang valid!");
                return false;
            }
            
            return true;
        },

        konfirmasiBooking() {
            if (!this.nama || !this.nomorTelepon || !this.jamMulai || !this.lapanganDipilih || !this.tanggalBooking) {
                alert("Mohon lengkapi semua data!");
                return;
            }
            
            if (!this.isValidBooking()) {
                return;
            }
            
            if (!this.isSlotAvailable(this.jamMulai, this.jamSelesai, this.tanggalBooking, this.lapanganDipilih)) {
                alert("Waktu yang dipilih sudah dibooking! Pilih waktu lain.");
                return;
            }
            
            this.bookings[this.lapanganDipilih].push({
                nama: this.nama,
                tanggal: this.tanggalBooking,
                jamMulai: this.jamMulai,
                jamSelesai: this.jamSelesai
            });
            
            localStorage.setItem('bookings', JSON.stringify(this.bookings));
            alert(`Booking Lapangan ${this.lapanganDipilih} berhasil!`);
            setTimeout(() => {
                window.location.href = '/penjadwalan/jadwal.html';
            }, 1000);
        }
    };
}

// Sidebar
document.addEventListener('DOMContentLoaded', function () {
    const menuButton = document.getElementById('menu-button');
    const sidebar = document.getElementById('sidebar');
    const overlay = document.getElementById('overlay');
    const closeButton = document.getElementById('close-button');

    // Buka sidebar
    menuButton.addEventListener('click', function () {
        sidebar.classList.add('open');
        overlay.classList.add('show');
    });

    // Tutup sidebar
    overlay.addEventListener('click', function () {
        sidebar.classList.remove('open');
        overlay.classList.remove('show');
    });

    document.querySelectorAll('.card-title').forEach(item => {
        item.addEventListener('click', function () {
            const selectedField = this.textContent;
            localStorage.setItem('selectedField', selectedField);
            window.location.href = '#';
        });
    });
});

// Sub Menu
let subMenu = document.getElementById("subMenu");

function toggleMenu() {
    subMenu.classList.toggle("open-menu");
}
